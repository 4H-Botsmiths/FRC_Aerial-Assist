#ifndef ITERATIVE_ROBOT_H
#define ITERATIVE_ROBOT_H
#include <iostream>

#define START_ROBOT_CLASS(RobotClass)\
	int main()\
	{\
		RobotClass robot;\
		robot.RobotInit();\
		\
		std::cout << "What mode do you want to run?\n"; \
		std::cout << "(a) Autonomous mode\n"; \
		std::cout << "(b) Teleop mode\n"; \
		\
		char mode = 'a';\
		std::cin >> mode;\
		\
		if ( mode == 'a' || mode == 'A' )\
		{\
			robot.AutonomousInit();\
			\
			while ( true )\
			{\
				robot.AutonomousPeriodic();\
			}\
		}\
		else\
		{\
			robot.TeleopInit(); \
			\
			while ( true )\
			{\
				robot.TeleopPeriodic(); \
			}\
		}\
		\
		return 0;\
	}\

class IterativeRobot
{
public:

	virtual ~IterativeRobot(){}

	virtual void RobotInit() = 0;

	virtual void AutonomousInit() = 0;

	virtual void TeleopInit() = 0;

	virtual void AutonomousPeriodic() = 0;

	virtual void TeleopPeriodic() = 0;

	virtual void DisabledInit() = 0;
	
	virtual void DisabledPeriodic() = 0;
	
	virtual void TestInit() = 0;

	virtual void TestPeriodic() = 0;
};

#endif
