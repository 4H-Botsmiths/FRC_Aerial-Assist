#ifndef VICTOR_H
#define VICTOR_H

class Victor
{
public:

	Victor(int portNum)
	{}

	void Set(float speed){}
};

#endif
