#ifndef RELAY_H
#define RELAY_H

class Relay
{
public:

	Relay(unsigned int port)
	{}

	void Set(unsigned int direction){}

	static const unsigned int kOn = 0;
	static const unsigned int kOff = 1;
	static const unsigned int kForward = 0;
	static const unsigned int kReverse = 1;
};

#endif
