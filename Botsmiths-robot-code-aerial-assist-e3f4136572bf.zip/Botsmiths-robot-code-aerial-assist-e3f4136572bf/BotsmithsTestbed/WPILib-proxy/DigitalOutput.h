#ifndef DIGITAL_OUTPUT_H
#define DIGITAL_OUTPUT_H

class DigitalOutput
{
public:

	DigitalOutput(int portNum)
	{}

};

#endif
