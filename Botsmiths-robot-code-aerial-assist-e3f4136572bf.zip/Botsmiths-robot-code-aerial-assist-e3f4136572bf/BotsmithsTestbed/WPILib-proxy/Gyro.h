#ifndef GYRO_H
#define GYRO_H

class Gyro
{
public:

	Gyro(int portNum)
	{}

	float GetAngle(){ return 0.0f; }
};

#endif
