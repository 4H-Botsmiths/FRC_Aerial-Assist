#ifndef WPILIB_PROXY_H
#define WPILIB_PROXY_H

#include <string>
#include <iostream>
#include <map>
#include <vector>

#include "DigitalOutput.h"
#include "DigitalInput.h"
#include "Timer.h"
#include "Joystick.h"
#include "Gyro.h"
#include "ADXL345_SPI.h"
#include "AnalogChannel.h"
#include "Victor.h"
#include "Jaguar.h"
#include "IterativeRobot.h"
#include "Relay.h"
#include "Talon.h"

#endif
