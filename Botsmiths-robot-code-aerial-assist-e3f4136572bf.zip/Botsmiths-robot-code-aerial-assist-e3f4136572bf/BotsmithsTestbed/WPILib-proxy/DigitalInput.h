#ifndef DIGITAL_INPUT_H
#define DIGITAL_INPUT_H

class DigitalInput
{
public:

	DigitalInput(int portNum)
	{}

};

#endif
