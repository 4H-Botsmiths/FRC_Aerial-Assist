#ifndef JOYSTICK_H
#define JOYSTICK_H

class Joystick
{
public:

	Joystick(int portNum)
	{}

	float GetRawAxis(unsigned int axis){ return 0.0f; }

	bool GetRawButton(unsigned int btn){ return false; }
};

#endif
