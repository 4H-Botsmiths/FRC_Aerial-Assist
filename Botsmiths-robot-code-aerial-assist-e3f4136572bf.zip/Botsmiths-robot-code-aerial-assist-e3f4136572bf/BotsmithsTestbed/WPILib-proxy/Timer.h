#ifndef TIMER_H
#define TIMER_H

class Timer
{
public:

	double Get(){ return 0.0; }

	void Start(){}

	void Reset(){}
};

#endif
