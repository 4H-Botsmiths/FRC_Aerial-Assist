#ifndef TALON_H
#define TALON_H

class Talon
{
public:

	Talon(int portNum)
	{}

	void Set(float speed){}
};

#endif
