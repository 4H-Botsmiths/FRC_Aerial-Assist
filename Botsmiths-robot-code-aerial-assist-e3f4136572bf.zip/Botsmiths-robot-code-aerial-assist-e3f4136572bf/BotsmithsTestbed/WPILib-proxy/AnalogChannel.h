#ifndef ANALOG_CHANNEL_H
#define ANALOG_CHANNEL_H

class AnalogChannel
{
public:

	AnalogChannel(int portNum)
	{}

	float GetVoltage(){ return 0.0f; }
};

#endif
