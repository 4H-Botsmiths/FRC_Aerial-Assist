#ifndef JAGUAR_H
#define JAGUAR_H

class Jaguar
{
public:

	Jaguar(int portNum)
	{}

	void Set(float speed){}
};

#endif
