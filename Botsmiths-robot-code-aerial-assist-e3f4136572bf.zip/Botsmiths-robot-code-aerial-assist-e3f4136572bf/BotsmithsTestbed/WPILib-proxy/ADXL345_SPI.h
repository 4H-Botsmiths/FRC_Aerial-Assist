#ifndef ADXL345_SPI_H
#define ADXL345_SPI_H
#include "DigitalOutput.h"
#include "DigitalInput.h"

class ADXL345_SPI
{
public:

	ADXL345_SPI(DigitalOutput* in1, DigitalOutput* in2, DigitalInput* in3, DigitalOutput* in4)
	{}

	float GetAcceleration(unsigned int axis){ return 0.0f; }

	static const unsigned int kAxis_X = 0;
	static const unsigned int kAxis_Y = 0;
	static const unsigned int kAxis_Z = 0;
};

#endif
