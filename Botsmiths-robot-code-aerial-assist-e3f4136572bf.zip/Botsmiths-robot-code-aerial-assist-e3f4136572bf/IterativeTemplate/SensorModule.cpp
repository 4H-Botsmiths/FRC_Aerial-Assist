#include "SensorModule.h"
#include <iostream>
#define GRIP 0.05f

bool SensorModule::init(BotsmithsBot* bot)
{
	load();

	return true;
}

SensorModule::~SensorModule()
{
	for(unsigned int i = 0; i < m_sensorFactory.size(); ++i)
	{
		delete m_sensorFactory[i];
	}
	
	m_sensorFactory.clear();
}
	
float SensorModule::getDistanceFromFront()
{
	float volt = m_ultrasonic.GetVoltage() * 110;
	
	return volt;
}

ISensor* SensorModule::addSensor(const std::string& type, std::string name, tinyxml2::XMLElement* sensor)
{
	ISensor* ret = NULL;
	
	for(unsigned int i = 0; i < m_sensorFactory.size(); ++i)
	{
		ret = m_sensorFactory[i]->createSensor(type, sensor);
		
		if (ret)
			break;
		
	}
	
	if (ret)
	{
		m_sensorMap[name] = ret;
	}
	
	cout << "Added a sensor!! of type " << type << " and name " << name << endl;
	return ret;
}

ISensor* SensorModule::getSensor(const std::string& name)
{
	std::map<std::string, ISensor*>::iterator i = m_sensorMap.find(name);
	if ( i != m_sensorMap.end() )
	{
		return i->second;
	}
	
	return NULL;
}

void SensorModule::update()
{
	std::map<std::string, ISensor*>::iterator iter;
	for (iter = m_sensorMap.begin(); iter != m_sensorMap.end(); iter++)
	{
		ISensor* sensor = iter->second;
		SmartDashboard::PutNumber(iter->first, (double)sensor->getValue());
	}
}

void SensorModule::load()
{
	m_sensorMap.clear();
	//TODO: Load sensors from here using port names or hard coded port numbers from the XML
	tinyxml2::XMLDocument doc;
	doc.LoadFile("sensors.xml");
	tinyxml2::XMLElement* sensors = doc.FirstChildElement("sensors");
	
	if (sensors)
	{
		tinyxml2::XMLElement* sensor = sensors->FirstChildElement("sensor");
		while (sensor)
		{
			std::string typeNameAtt = sensor->Attribute("type"); 
			std::string NameAtt = sensor->Attribute("name");
			addSensor(typeNameAtt, NameAtt, sensor);
			
			sensor = sensor->NextSiblingElement("sensor");
		}
	}
	
}

