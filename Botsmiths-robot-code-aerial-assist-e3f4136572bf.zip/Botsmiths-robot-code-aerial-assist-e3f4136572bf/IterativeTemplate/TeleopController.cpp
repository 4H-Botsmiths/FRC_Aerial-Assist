#include "TeleopController.h"
#define TARGETANGLE 1.2
#define BACK_SWING_TIME 5.0
#define FRONT_SWING_TIME 6.0


bool TeleopController::init(BotsmithsBot* bot)
{
	clock.Start();
	m_driveMod = (DriveModule*)bot->getModule(EMT_DRIVE_MODULE);
	m_armLaunch = (ArmAndLauncher*)bot->getModule(EMT_ARM_LAUNCHER);
	m_sensorMod = (SensorModule*)bot->getModule(EMT_SENSOR);

	return true;
}

void TeleopController::update()
{
	m_driveMod->drive(m_joystick.GetRawAxis(1), m_joystick.GetRawAxis(2), m_joystick.GetRawAxis(4));
	
	float hammer = 0.0f;
	
	//Arm
	/*if (m_joystick2.GetRawButton(FIRE_BUTTON))
	{
		m_armLaunch->moveArm(((m_sensorMod->getArmAngle()-TARGETANGLE)/TARGETANGLE)*0.5f);
	}
	else*/
	{
		m_armLaunch->moveArm(m_joystick2.GetRawAxis(2)*0.5f);
	}
	
	//Firing
	{
		hammer = -m_joystick2.GetRawAxis(4);
		
		if ( hammer < 0.0f )
			hammer *= 0.6f;
		else
			hammer *= 1.0f;
	}
		/*
	if (m_joystick.GetRawButton(FIRE_BUTTON) && m_hammerFlag)
	{
		m_hammerFlag = false;
		if (m_state == EHS_OFF)
		{
			m_state = EHS_BACK_SWING;
			clock.Reset();
		}
	}
	else 
		m_hammerFlag = true;
	
	if (m_state != EHS_OFF)
	{
		if (m_state == EHS_BACK_SWING)
		{
			hammer = 0.5;
			if (clock.Get() >= BACK_SWING_TIME)
				m_state = EHS_FRONT_SWING;
		}
		else if (m_state == EHS_FRONT_SWING)
		{
			hammer = -1;
			if (clock.Get() >= FRONT_SWING_TIME)
				m_state = EHS_OFF;
		}
	}*/
	
	m_armLaunch->moveHammer(hammer);
}
