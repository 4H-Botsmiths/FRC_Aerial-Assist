#ifndef MOTOR_IMPLEMENT_H
#define MOTOR_IMPLEMENT_H
#include "IMotor.h"
#include "WPILib.h"
#include "PortManager.h"
#include "MathUtils.h"

class CJaguarMotor: public IMotor
{
public:
	
	MOTOR_TYPE(CJaguarMotor)
	
	CJaguarMotor(const std::string& portName)
	: m_jaguar(PortManager::getPort(portName))
	{
		
	}
	
	void set(float power)
	{
		m_jaguar.Set(MathUtils::round(power));
	}
	
private:
	
	Jaguar m_jaguar;
};

class CVictorMotor: public IMotor
{
public:
		
	MOTOR_TYPE(CVictorMotor)
	
	CVictorMotor(const std::string& portName)
	: m_victor(PortManager::getPort(portName))
	{
		
	}
	
	void set(float power)
	{
		m_victor.Set(MathUtils::round(power));
	}
	
private:
	
	Victor m_victor;
};

class CTalonMotor : public IMotor
{
public:

	MOTOR_TYPE(CTalonMotor)

		CTalonMotor(const std::string& portName)
		: m_talon(PortManager::getPort(portName))
	{

	}

	void set(float power)
	{
		m_talon.Set(MathUtils::round(power));
	}

private:

	Talon m_talon;
};

class CSpikeRelay: public IMotor
{
public:
	
	MOTOR_TYPE(CSpikeRelay)
	
	CSpikeRelay(const std::string& portName)
	: m_spikeRelay(PortManager::getPort(portName))
	{
		
	}
	
	void set(float power)
	{
		if (MathUtils::round(power) > 0)
		{
			m_spikeRelay.Set(Relay::kForward);
		}
		else if (MathUtils::round(power) < 0)
		{
			m_spikeRelay.Set(Relay::kReverse);
		}
		else
		{
			m_spikeRelay.Set(Relay::kOff);
		}
	}
	
private:
	
	Relay m_spikeRelay;
};

#endif
