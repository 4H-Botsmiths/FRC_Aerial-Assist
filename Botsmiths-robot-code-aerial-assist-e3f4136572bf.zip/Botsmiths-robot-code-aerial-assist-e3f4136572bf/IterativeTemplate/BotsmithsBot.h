#ifndef BOTSMITHS_BOT_H
#define BOTSMITHS_BOT_H
#include "WPILib.h"
#include <vector>
#include <memory>
#include "IModule.h"

class IController;

class BotsmithsBot : public IterativeRobot
{
public:
	
	BotsmithsBot()
	{
	
	}
	
	~BotsmithsBot();
	
	//register modules here
	void RobotInit();
	
	//register autonomus controller here
	void AutonomousInit();
	
	//register teleop controller here
	void TeleopInit();
	
	void AutonomousPeriodic();
	
	void TeleopPeriodic();
	
	void registerModule(IModule* mod);
	
	IModule* getModule(unsigned int type);
	//template <class T> T* getModule(){return (T*)getModule(T::getClassType());}
	
	void setController(IController* control);
	
	void DisabledInit(){}
	void DisabledPeriodic(){}
	void TestInit(){}
	void TestPeriodic(){}
	
private:
	std::auto_ptr<IController> m_controller;
	std::vector<IModule*> m_modules;
};


#endif
