#ifndef DIGITAL_SENSOR_H
#define DIGITAL_SENSOR_H
#include "WPIlib.h"
#include "ISensor.h"

class DigitalSensor : public ISensor
{
public:
	SENSOR_TYPE(DigitalSensor)
	
	DigitalSensor(unsigned int port, bool closedTrue=true)
	:m_input(port),
	 m_closedTrue(closedTrue)
	{
		
	}
	
	float getValue()
	{
		if ( isTriggered() )
		{
			return 1.0f;
		}
		
		return 0.0f;
	}
	
	bool isTriggered()
	{
		return m_input.Get() && closedTrue;
	} 
	
private:
	
	DigitalInput m_input;
	bool m_closedTrue;
};

#endif
