#ifndef I_MOTOR_H
#define I_MOTOR_H
#include "StringUtils.h"
#include "tinyxml2.h"

#define MOTOR_TYPE(type)\
	static unsigned int getClassType()\
	{\
		static unsigned int ret = StringUtils::stringHash(#type);\
		return ret;\
	}\
	virtual unsigned int getType()\
	{\
		return type::getClassType();\
	}\
	static std::string getClassTypeName()\
	{\
		return #type;\
	}\
	virtual std::string getTypeName()\
	{\
		return #type;\
	}

class IMotor//ISensor
{
public:
	
	virtual ~IMotor() {}
	
	virtual void set(float power) = 0;
	
	virtual unsigned int getType() = 0;
	
	virtual std::string getTypeName() = 0;
};

class IMotorFactory
{
public:
	
	virtual ~IMotorFactory() {}
	
	virtual IMotor* createMotor(const std::string& type, tinyxml2::XMLElement* motor) = 0;
};

#endif
