#include "DefaultSensorFactory.h"
#include "AnalogSensor.h"
#include "PortManager.h"

ISensor* DefaultSensorFactory::createSensor(const std::string& typeName, tinyxml2::XMLElement* sensor)
{
	if(typeName == AnalogSensor::getClassTypeName())
	{
		return new AnalogSensor(PortManager::getPort(sensor->Attribute("port")), sensor->FloatAttribute("maxVoltage") , sensor->FloatAttribute("maxValue"));
	}
	
	return 0;
}
