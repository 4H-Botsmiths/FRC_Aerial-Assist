#include "MotorModule.h"
#include <iostream>
#define GRIP 0.05f

bool MotorModule::init(BotsmithsBot* bot)
{
	load();

	return true;
}

MotorModule::~MotorModule()
{
	for(unsigned int i = 0; i < m_motorFactory.size(); ++i)
	{
		delete m_motorFactory[i];
	}
	
	m_motorFactory.clear();
}

IMotor* MotorModule::addMotor(const std::string& type, std::string name, tinyxml2::XMLElement* motor)
{
	IMotor* ret = NULL;
	
	for(unsigned int i = 0; i < m_motorFactory.size(); ++i)
	{
		ret = m_motorFactory[i]->createMotor(type, motor);
		
		if (ret)
			break;
	}
	
	if (ret)
	{
		m_motorMap[name] = ret;
	}
	
	return ret;
}

IMotor* MotorModule::getMotor(const std::string& name)
{
	std::map<std::string, IMotor*>::iterator i = m_motorMap.find(name);
	if ( i != m_motorMap.end() )
	{
		return i->second;
	}
	
	return NULL;
}

void MotorModule::load()
{
	m_motorMap.clear();
	tinyxml2::XMLDocument doc;
	doc.LoadFile("motors.xml");
	
	tinyxml2::XMLElement* motors = doc.FirstChildElement("motors");
	if (motors)
	{
		cout << "Found motor file" << endl;
		tinyxml2::XMLElement* motor = motors->FirstChildElement("motor");
		while (motor)
		{
			std::string typeNameAtt = motor->Attribute("type"); 
			std::string NameAtt = motor->Attribute("name");
			IMotor* m = addMotor(typeNameAtt, NameAtt, motor);
			if (m)
				cout << "Loaded motor named " << NameAtt << " of type " << typeNameAtt << endl;
			
			motor = motor->NextSiblingElement("motor");
		}
	}
	
}
