//DEPRECATED FOR 2015
#ifndef ARMANDLAUNCHER_H
#define ARMANDLAUNCHER_H
#include "IModule.h"
#include "ports.h"
#include "WPILib.h"

class ArmAndLauncher : public IModule
{
public:

	//MODULE(DriveModule)
	
	ArmAndLauncher()
		:m_launcher(MOTOR_HAMMER),
		 m_lifter(MOTOR_LIFTER)
		// m_switch1(SWITCH_1),
		// m_switch2(SWITCH_2)
	{
		
	}
	void update(){}
	
	bool init(BotsmithsBot* bot){return true;}
	
	void moveHammer(float rotate);
	
	void moveArm(float armMove);
	
	unsigned int getType(){return EMT_ARM_LAUNCHER;}
	
private:

	Victor m_launcher;
	Jaguar m_lifter;
	//DigitalInput m_switch1;
	//DigitalInput m_switch2;
};

#endif
