#ifndef DEFAULT_MOTOR_FACTORY
#define DEFAULT_MOTOR_FACTORY
#include "IMotor.h"
#include "tinyxml2.h"

class DefaultMotorFactory : public IMotorFactory
{
public:
	
	IMotor* createMotor(const std::string& typeName, tinyxml2::XMLElement* motor);
};

#endif
