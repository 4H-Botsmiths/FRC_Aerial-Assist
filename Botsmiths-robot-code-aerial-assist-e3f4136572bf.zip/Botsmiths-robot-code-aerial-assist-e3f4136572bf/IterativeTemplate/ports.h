#ifndef PORTS_H
#define PORTS_H

#define MOTOR_FRONT_LEFT 1
#define MOTOR_FRONT_RIGHT 8
#define MOTOR_BACK_LEFT 3
#define MOTOR_BACK_RIGHT 4
#define MOTOR_LIFTER 7
#define MOTOR_HAMMER 6
#define ARM_ANGLE_SENSOR 3
#define ULTRASONIC_SENSOR 2
#define GYRO_TASTIC 1
#define ACCEL_START_PORT 1//Takes up the following three as well

#endif
