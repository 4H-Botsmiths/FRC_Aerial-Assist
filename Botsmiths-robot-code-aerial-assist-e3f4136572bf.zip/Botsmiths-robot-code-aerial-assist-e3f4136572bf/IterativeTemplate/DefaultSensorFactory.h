#ifndef DEFAULT_SENSOR_FACTORY
#define DEFAULT_SENSOR_FACTORY
#include "ISensor.h"
#include "tinyxml2.h"

class DefaultSensorFactory:public ISensorFactory
{
public:
	
	ISensor* createSensor(const std::string& typeName, tinyxml2::XMLElement* sensor);
};

#endif
