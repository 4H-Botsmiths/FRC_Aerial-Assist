#ifndef IMODULE_H
#define IMODULE_H 

class BotsmithsBot;

enum E_MODULE_TYPE
{
	EMT_DRIVE_MODULE, 
	EMT_ARM_LAUNCHER,
	EMT_SENSOR,
	EMT_PORT_MANAGER,
	EMT_MOTOR_MODULE
};

class IModule
{
public:
	
	virtual ~IModule()
	{
		
	}
	
	virtual void update() {}
	
	virtual bool init(BotsmithsBot* bot)=0;
	
	virtual unsigned int getType() = 0;
};
#endif
