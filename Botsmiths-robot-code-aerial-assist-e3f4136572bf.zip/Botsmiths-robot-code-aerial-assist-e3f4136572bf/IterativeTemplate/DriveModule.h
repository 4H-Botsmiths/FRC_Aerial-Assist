//DEPRECATED FOR 2015 MECHANUM WHEEL DRIVE CODE WILL BE PORTED
#ifndef DRIVEMODULE_H
#define DRIVEMODULE_H
#include "IModule.h"
#include "ports.h"
#include "WPILib.h"

class DriveModule : public IModule
{
public:
	
	//MODULE(DriveModule)
	
	DriveModule()
	:m_leftFront(MOTOR_FRONT_LEFT),
	m_rightFront(MOTOR_FRONT_RIGHT),
	m_leftBack(MOTOR_BACK_LEFT),
	m_rightBack(MOTOR_BACK_RIGHT)
	{
		
	}
	
	void update(){}
	
	void drive(float xSpeed, float ySpeed, float rotate);
	
	void tankDrive(float left, float right);
	
	bool init(BotsmithsBot* bot){return true;}
	
	unsigned int getType(){return EMT_DRIVE_MODULE;}
	
private:
	
	Victor m_leftFront;
	Victor m_rightFront;
	Victor m_leftBack;
	Victor m_rightBack;
};

#endif
