#include "BotsmithsBot.h"
#include "IController.h"
#include "ArmAndLauncher.h"
#include "DriveModule.h"
#include "TeleopController.h"
#include "SensorModule.h"
#include "AutonomousOp.h"
#include "PortManager.h"
#include "MotorModule.h"

BotsmithsBot::~BotsmithsBot()
{
	for (unsigned int i=0; i<m_modules.size(); ++i)
	{
		delete m_modules[i];
	}

	m_modules.clear();
}

//register modules here
void BotsmithsBot::RobotInit() 
{
	SmartDashboard::init();
	registerModule(new PortManager); //HAS to be first initialized. Ports must be loaded before others.
	
	registerModule(new SensorModule);
	registerModule(new MotorModule);
	
	registerModule(new DriveModule);
	registerModule(new ArmAndLauncher);
}

//register autonomus controller here
void BotsmithsBot::AutonomousInit() 
{
	setController(new AutonomousOp);
}

//register teleop controller here
void BotsmithsBot::TeleopInit() 
{
	setController(new TeleopController);
}

void BotsmithsBot::AutonomousPeriodic() 
{
	if ( m_controller.get() )
		m_controller->update();
	
	for (unsigned int i=0; i<m_modules.size(); ++i)
	{
		m_modules[i]->update();
	}
}

void BotsmithsBot::TeleopPeriodic() 
{
	if ( m_controller.get() )
		m_controller->update();
	
	for (unsigned int i=0; i<m_modules.size(); ++i)
	{
		m_modules[i]->update();
	}
}

void BotsmithsBot::registerModule(IModule* mod)
{
	m_modules.push_back(mod);
	mod->init(this);
}

IModule* BotsmithsBot::getModule(unsigned int type)
{
	for (unsigned int i=0; i<m_modules.size(); ++i)
	{
		if (m_modules[i]->getType()==type)
			return m_modules[i];
	}
	
	return NULL;
}

void BotsmithsBot::setController(IController* control)
{
	m_controller.reset(control);
	control->init(this);
}

START_ROBOT_CLASS(BotsmithsBot);
