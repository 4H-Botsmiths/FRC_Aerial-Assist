#ifndef AUTONOMOUS_H
#define AUTONOMOUS_H
#include "ArmAndLauncher.h"
#include "IController.h"
#include "WPILib.h"
#include "DriveModule.h"
#include "SensorModule.h"

enum E_AUTO_STATE
{
	EAS_MOVE_FORWARD,
	EAS_SWING,
	EAS_END
};

class AutonomousOp : public IController
{
public:
	
	AutonomousOp()
	:m_state(EAS_MOVE_FORWARD)
	{
		
	}
	
	void update();
	
	bool init(BotsmithsBot* bot);
	
private:
	
	DriveModule* m_driveMod;
	ArmAndLauncher* m_armLaunch;
	Timer clock;
	SensorModule* m_sensorMod;
	E_AUTO_STATE m_state;
	float m_StartDist;
};

#endif
