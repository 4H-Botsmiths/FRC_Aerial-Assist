#include "DefaultMotorFactory.h"
#include "MotorImplementation.h"

IMotor* DefaultMotorFactory::createMotor(const std::string& typeName, tinyxml2::XMLElement* motor)
{
	//Only the part of the function where the motor was created had to be commented out.
	
	if(typeName == CJaguarMotor::getClassTypeName())
	{
		return new CJaguarMotor(motor->Attribute("port"));
	}
	
	else if (typeName == CVictorMotor::getClassTypeName())
	{
		return new CVictorMotor(motor->Attribute("port"));
	}

	else if (typeName == CTalonMotor::getClassTypeName())
	{
		return new CTalonMotor(motor->Attribute("port"));
	}
	
	else if (typeName == CSpikeRelay::getClassTypeName())
	{
		return new CSpikeRelay(motor->Attribute("port"));
	}
	
	return 0;
} 
