#ifndef PORTMANAGER_H
#define PORTMANAGER_H
#include "IModule.h"
#include "ports.h"
#include "WPILib.h"
#include "tinyxml2.h"
#include <map>
#include <climits>
#define PORT_NOT_FOUND UINT_MAX

class PortManager : public IModule
{
public:

	PortManager()
	{
		
	}

	void update(){}
	
	bool init(BotsmithsBot* bot);
	
	unsigned int getType(){return EMT_PORT_MANAGER;}
	
	static unsigned int getPort(const std::string& name)
	{
		std::map<std::string, unsigned int>::iterator iter = m_portMap.find(name);
		
		if (iter != m_portMap.end())
			return iter->second;
		
		return PORT_NOT_FOUND;
		
	}
	
	static void addPort(const std::string& name, unsigned int portNum)
	{
		m_portMap[name] = portNum;
	}
	
	void load();
	
	
private:

	static std::map<std::string, unsigned int> m_portMap;
};

#endif
