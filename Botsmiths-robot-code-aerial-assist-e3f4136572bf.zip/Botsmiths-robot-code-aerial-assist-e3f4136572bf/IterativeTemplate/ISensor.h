#ifndef I_SENSOR_H
#define I_SENSOR_H
#include "StringUtils.h"
#include "tinyxml2.h"

#define SENSOR_TYPE(type)\
	static unsigned int getClassType()\
	{\
		static unsigned int ret = StringUtils::stringHash(#type);\
		return ret;\
	}\
	virtual unsigned int getType()\
	{\
		return type::getClassType();\
	}\
	static std::string getClassTypeName()\
	{\
		return #type;\
	}\
	virtual std::string getTypeName()\
	{\
		return #type;\
	}

//TODO: This interface should be extended so that sensors of different types can be implemented. 
//For example: an ultrasonic sensor that doesn't use analog could implement the interface, and be functional without changing code.
//Likewise, if the sensor broke and needed to be switched out, then it could be easily switched with only minor differences in functionality.
//Having an abstracted sensor interface makes the robot much more fault tolerant and allows us to be adaptable on competition day.
class ISensor
{
public:
	
	virtual ~ISensor() {}
	
	virtual float getValue()
	{
		return 0;
	}
	
	virtual bool isTriggered()
	{
		return true;
	} 
	
	virtual unsigned int getType() = 0;
	
	virtual std::string getTypeName() = 0;
};

class ISensorFactory
{
public:
	
	virtual ~ISensorFactory() {}
	
	virtual ISensor* createSensor(const std::string& type, tinyxml2::XMLElement* sensor) = 0;
};

#endif
