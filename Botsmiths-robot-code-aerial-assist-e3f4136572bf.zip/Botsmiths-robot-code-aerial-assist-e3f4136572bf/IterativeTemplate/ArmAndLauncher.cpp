//DEPRECATED FOR 2015
#include "ArmAndLauncher.h"
#include <iostream>
#define ARMTHRESH 0.15f

void ArmAndLauncher::moveHammer(float rotate)
{
	if (-ARMTHRESH > rotate && rotate > ARMTHRESH)
		rotate = 0;
	
	m_launcher.Set(rotate);
}

void ArmAndLauncher::moveArm(float rotArm)
{
	if (-ARMTHRESH > rotArm && rotArm > ARMTHRESH)
		rotArm = 0;
	
	m_lifter.Set(rotArm);
}

