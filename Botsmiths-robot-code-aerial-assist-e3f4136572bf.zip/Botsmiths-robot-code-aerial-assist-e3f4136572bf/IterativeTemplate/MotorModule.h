#ifndef MOTOR_MODULE_H//MOTOR_H
#define MOTOR_MODULE//MOTOR_H
#include "IModule.h"
#include "IMotor.h"
#include "ports.h"
#include "WPILib.h"
#include "DefaultMotorFactory.h"
#include "tinyxml2.h"
#include <iostream>

class MotorModule: public IModule
{
public:

	~MotorModule();
	
	MotorModule()
	{
		addMotorFactory(new DefaultMotorFactory);
	}
	
	bool init(BotsmithsBot* bot);
	
	IMotor* addMotor(const std::string& type, std::string name, tinyxml2::XMLElement* motor);
	
	IMotor* getMotor(const std::string& name);
	
	void addMotorFactory(IMotorFactory* iMotorFactoryPointer)
	{
		m_motorFactory.push_back(iMotorFactoryPointer);
	}
	
	unsigned int getType()
	{
		return EMT_MOTOR_MODULE;
	}
	
	void load();
	
private:

	std::vector<IMotorFactory*> m_motorFactory;
	std::map<std::string, IMotor*> m_motorMap;
};

#endif
