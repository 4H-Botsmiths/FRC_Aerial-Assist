//DEPRECATED FOR 2015 MECHANUM WHEEL DRIVE CODE WILL BE PORTED
#include "DriveModule.h"
#include <iostream>
#define THRESHOLD 0.15f

void DriveModule::drive(float xSpeed, float ySpeed, float rotate)
{
	if (-THRESHOLD > xSpeed && xSpeed > THRESHOLD)
		xSpeed = 0;
	
	if (-THRESHOLD > ySpeed && ySpeed > THRESHOLD)
		ySpeed = 0;
	
	if (-THRESHOLD > rotate && rotate > THRESHOLD)
		rotate = 0;
	
	m_leftFront.Set((-ySpeed + xSpeed + rotate) / 2);
	m_rightFront.Set((ySpeed + xSpeed + rotate) / 2);
	m_leftBack.Set((-ySpeed - xSpeed + rotate) / 2);
	m_rightBack.Set((ySpeed - xSpeed + rotate) / 2);
}

void DriveModule::tankDrive(float left, float right)
{
	m_leftFront.Set(left);
	m_rightFront.Set(-right);
	m_leftBack.Set(left);
	m_rightBack.Set(-right);
}
