#include "AutonomousOp.h"
#include <iostream>

#define FORWARDDIST 50
#define SWINGBACK 3.0
#define SWINGFORWARD 1.2
//#define TARGETANGLE 0.15
#define TARGETANGLE 1.0
#define ANGLETHRESH 0.01
//#define COASTDIST 5

bool AutonomousOp::init(BotsmithsBot* bot)
{
	m_driveMod = (DriveModule*)bot->getModule(EMT_DRIVE_MODULE);
	m_armLaunch = (ArmAndLauncher*)bot->getModule(EMT_ARM_LAUNCHER);
	m_sensorMod = (SensorModule*)bot->getModule(EMT_SENSOR);

	m_StartDist=m_sensorMod->getDistanceFromFront();

	return true;
}

void AutonomousOp::update()
{
	float goForward = 0.0;
	bool swingBack = false;
	bool swingForward = false;
	
	if ( m_state == EAS_MOVE_FORWARD )
	{
		if (m_sensorMod->getDistanceFromFront() > FORWARDDIST)
		{
			goForward = 1.0f;//(m_sensorMod->getDistanceFromFront()/m_StartDist)*1.2f;
			
			/*if (m_sensorMod->getDistanceFromFront() < FORWARDDIST + COASTDIST)
					{
						goForward = 0.5f;
					}*/
		}
		
		else
		{
			goForward = 0.0f;
			clock.Start();
			m_state = EAS_SWING;
		}
	}

	else if ( m_state == EAS_SWING )
	{
		swingBack = true;
		swingForward = false;
		
		if (clock.Get() >= SWINGBACK + SWINGFORWARD)
		{
			m_state = EAS_END;
			//m_armLaunch->moveArm(0.45f);
		}
		else if (clock.Get() >= SWINGBACK /*&& m_sensorMod->getArmAngle()>= 0.85f*/)
		{
			swingBack = false;
			swingForward = true;
		}
	}
	else if ( EAS_END)
	{
		goForward = 0.0f;
		swingBack = false;
		swingForward = false;
	}
		
	if (goForward)
	{
		m_driveMod->tankDrive(goForward * 0.4f, goForward * 0.4f); //move forward
	}
	else
		m_driveMod->drive(0, 0, 0); //stop moving

	/*if (swingBack)
		m_armLaunch->moveHammer(-0.6f); //Swing hammer backward
	
	else if (swingForward)
		m_armLaunch->moveHammer(1.0f); //Move hammer forward
	else
		*/
		m_armLaunch->moveHammer(0); //Stop hammer 
	
	//angle arm
	
	//m_armLaunch->moveArm(((m_sensorMod->getArmAngle()-TARGETANGLE)/TARGETANGLE)*0.33f);//Change multiplication to change speed.
	//m_armLaunch->moveArm(((TARGETANGLE-m_sensorMod->getArmAngle())/m_sensorMod->getArmAngle())*0.5f);
}
