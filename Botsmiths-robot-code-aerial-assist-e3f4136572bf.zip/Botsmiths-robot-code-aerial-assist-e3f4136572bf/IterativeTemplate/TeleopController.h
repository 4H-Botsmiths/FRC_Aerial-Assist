#ifndef TELEOPCONTROLLER_H
#define TELEOPCONTROLLER_H
#include "ArmAndLauncher.h"
#include "IController.h"
#include "WPILib.h"
#include "DriveModule.h"
#include "SensorModule.h"
//#define SAFETYSTOPANGLE 3.5

enum E_HAMMER_STATE
{
	EHS_OFF,
	EHS_BACK_SWING,
	EHS_FRONT_SWING
};

#define FIRE_BUTTON 5
#define TESLA_DEATH_RAY_BUTTON 4


#define JOYSTICK_PORT 1
#define JOYSTICK_PORT_2 2


class TeleopController : public IController
{
public:
	
	TeleopController()
		:m_joystick(JOYSTICK_PORT),
		m_joystick2(JOYSTICK_PORT_2),
		m_hammerFlag(true),
		m_state(EHS_OFF)
	{
		
	}
	
	void update();
	
	bool init(BotsmithsBot* bot);
	
private:
	
	DriveModule* m_driveMod;
	Joystick m_joystick;
	Joystick m_joystick2;
	ArmAndLauncher* m_armLaunch;
	SensorModule* m_sensorMod;
	Timer clock;
	E_HAMMER_STATE m_state;
	
	bool m_hammerFlag;
};

#endif
