#ifndef SENSOR_H
#define SENSOR_H
#include "IModule.h"
#include "ISensor.h"
#include "ports.h"
#include "WPILib.h"
#include "DefaultSensorFactory.h"
#include "tinyxml2.h"
#include <iostream>

class SensorModule: public IModule
{
public:

	//MODULE(DriveModule)
	
	~SensorModule();
	
	SensorModule()
	:m_ultrasonic(ULTRASONIC_SENSOR),
	 m_armAngle(ARM_ANGLE_SENSOR),
	 m_accel(new DigitalOutput(ACCEL_START_PORT), 
			 new DigitalOutput(ACCEL_START_PORT+1), 
			 new DigitalInput(ACCEL_START_PORT+2), 
			 new DigitalOutput(ACCEL_START_PORT+3)),
			tasty(GYRO_TASTIC)
	{
		addSensorFactory(new DefaultSensorFactory);
	}
	
	bool init(BotsmithsBot* bot);
	
	void update();
	
	ISensor* addSensor(const std::string& type, std::string name, tinyxml2::XMLElement* sensor);
	
	ISensor* getSensor(const std::string& name);
	
	void addSensorFactory(ISensorFactory* iSensorFactoryPointer)
	{
		m_sensorFactory.push_back(iSensorFactoryPointer);
	}
	
	void load();
	
private:

	std::vector<ISensorFactory*> m_sensorFactory;
	std::map<std::string, ISensor*> m_sensorMap;
	
	
	//=====================================================================================================
	//OLD/ARCHAIC/OBSOLETE CODE 
	//To be removed when porting to RoboRIO
	//=====================================================================================================
public:
	
	float getChassisRotation()
	{
		return tasty.GetAngle();
	}
	
	float getArmAngle()
	{
		return m_armAngle.GetVoltage();
	}
	
//	bool init(BotsmithsBot* bot)
//	{
//		tasty.Reset();
//		return true;
//	}
	
	float getDistanceFromFront();
	
	unsigned int getType(){return EMT_SENSOR;}
	
	float getAccelerationY()
	{
		return m_accel.GetAcceleration(ADXL345_SPI::kAxis_Y);
	}
	float getAccelerationX()
	{
		return m_accel.GetAcceleration(ADXL345_SPI::kAxis_X);
	}
	float getAccelerationZ()
	{
		return m_accel.GetAcceleration(ADXL345_SPI::kAxis_Z);
	}
	
private:
	AnalogChannel m_ultrasonic;
	AnalogChannel m_armAngle;
	ADXL345_SPI m_accel;
	Gyro tasty;
	//======================================================================================================
};

#endif
