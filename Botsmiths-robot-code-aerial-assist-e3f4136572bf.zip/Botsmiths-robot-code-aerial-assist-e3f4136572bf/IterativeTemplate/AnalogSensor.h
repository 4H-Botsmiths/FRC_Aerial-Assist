#ifndef ANALOG_H
#define ANALOG_H
#include "WPIlib.h"
#include "ISensor.h"

class AnalogSensor : public ISensor
{
public:
	SENSOR_TYPE(AnalogSensor)
	
	AnalogSensor(unsigned int channel, float maxVolt, float maxValu)
	:m_analogChannel(channel),
	 m_maxVolt(maxVolt),
	 m_maxValu(maxValu)
	{
		
	}
	
	float getVoltage()
	{
		return m_analogChannel.GetVoltage();
	}
	
	float getValue()
	{
		float volt = getVoltage();

		if (volt > m_maxVolt)
			volt = m_maxVolt;
		
		float scale = volt/m_maxVolt;
		
		return m_maxValu*scale;	
	}
	
	bool isTriggered()
	{
		return getVoltage() >= m_maxVolt/2;
	} 
	
private:
	
	AnalogChannel m_analogChannel;
	float m_maxVolt;
	float m_maxValu;
};

#endif
