#include "PortManager.h"

std::map<std::string, unsigned int> PortManager::m_portMap = std::map<std::string, unsigned int>();

bool PortManager::init(BotsmithsBot* bot)
{
	load();
		
	return true;
}

void PortManager::load()
{
	m_portMap.clear();
	tinyxml2::XMLDocument doc;
	doc.LoadFile("ports.xml");
	cout << "Port manager init called" << endl;
	tinyxml2::XMLElement* ports = doc.FirstChildElement("ports");
	if (ports)
	{
		cout << "Found port file" << endl;
		tinyxml2::XMLElement* port = ports->FirstChildElement("port");
		while (port)
		{
			m_portMap[port->Attribute("name")] = port->IntAttribute("number");
			cout << "Made port of name " << port->Attribute("name") << " and number " << port->IntAttribute("number") << endl;
			
			port = port->NextSiblingElement("port");
		}
	}
	
}
