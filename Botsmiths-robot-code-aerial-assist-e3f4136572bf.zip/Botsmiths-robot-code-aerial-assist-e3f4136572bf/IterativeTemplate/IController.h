#ifndef ICONTROLLER_H
#define ICONTROLLER_H 
#include "BotsmithsBot.h"

class IController
{
public:
	
	virtual ~IController()
	{
		
	}
	
	virtual void update()=0;
	
	virtual bool init(BotsmithsBot* bot)=0;
};
#endif
